# 11. 병렬 작업과 대량 처리 — 실습 시작하기

이 ZIP은 JupyterLab에서 실행하는 학습용 노트북 묶음입니다. 완성된 HTML 웹사이트가 아닙니다.
노트북 안에 예제 코드와 합성 입력 자료가 포함되어 있습니다. 기본 문법 실습을 먼저 마친 뒤 보안 적용 실습을 진행합니다.

## 실행 순서

Ubuntu VM 또는 WSL2 Ubuntu에서 Python 3.10 이상과 Bash를 준비합니다.
압축을 푼 뒤 이 파일과 `requirements.txt`가 있는 폴더에서 터미널을 엽니다.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
jupyter lab
```

JupyterLab에서 `notebooks/`를 열고 Python 3 커널을 선택합니다. `%%bash` 셀은 그대로 실행합니다.
설정 셀부터 위에서 아래로 Shift+Enter로 실행하고, Checks의 결과를 확인합니다.
서로 다른 Bash 셀 사이에서 일반 셸 변수나 `cd` 상태는 유지되지 않습니다.

1. `notebooks/11-bounded-parallel.ipynb`
2. `notebooks/security-11-web.ipynb`

전체 묶음에서는 노트북 번호와 교안 장 번호가 다를 수 있으므로 [장별 연결표](https://zxz3650.gitbook.io/bash-shell-programing/downloads)를 함께 봅니다.
01·02장의 환경 실습, 06·07장의 안전한 조사 실습은 여러 장에서 함께 사용합니다.

## 보관과 안전

- 개인 풀이를 다른 이름으로 저장합니다. 새 버전은 새 폴더에 풀어 기존 풀이를 보존합니다.
- 임시 실습 디렉터리는 영구 보관 장소가 아닙니다. Cleanup 전에 필요한 결과를 따로 저장합니다.
- 일반 사용자로 실행하고, Jupyter 서버를 외부에 공개하지 않습니다.
- 합성 자료를 사용하는 필수 실습과 실제 Linux 로그를 읽는 선택 VM 실습을 구분합니다.
- 터미널 프로젝트 전체 소스는 [저장소](https://github.com/zxz3650/Bash-shell-programing/blob/master/)에서 확인합니다. 이 ZIP은 노트북 실습용입니다.
- MANIFEST.json의 version은 자료 묶음의 내용 식별자이며 설치 패키지를 고정하는 값은 아닙니다.

[설치·실행·문제 해결 안내](https://zxz3650.gitbook.io/bash-shell-programing/practice) · [온라인 교안](https://zxz3650.gitbook.io/bash-shell-programing/)
